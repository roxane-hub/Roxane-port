Network and Port Scanning
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+ Understand the purpose of scanning during an attack.
+ See practical examples of network and port scanning.

Outline:
----------------------------------------------------------------
+ Active vs. Passive Scanning
+ Network Scanning
+ Port Scanning

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

