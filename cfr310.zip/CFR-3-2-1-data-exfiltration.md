Data Exfiltration
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Explore methods used by attackers to exfiltrate sensitive data from compromised networks.

Outline:
----------------------------------------------------------------
+ Covert channels
+ File sharing services

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

