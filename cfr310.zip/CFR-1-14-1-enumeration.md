Enumeration
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Learn the purpose of Enumeration and how it's done.

Outline:
----------------------------------------------------------------
+ User Enumeration
+ Application Enumeration
+ Network Enumeration
+ War Driving

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

