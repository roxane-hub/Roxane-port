Windows-Based Incident Response Tools
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Explore using Windows-based tools to analyze incidents.

Outline:
----------------------------------------------------------------
+ Registry
  - regedit
    + Key
    + Hives
    + Values
    + Value Types
  - regdump
  - Autoruns
+ Network
  - Wireshark
  - Foundstone's FPort
  - netstat
  - ipconfig
  - Nmap
  - tracert
  - net
  - nbtstat
+ File System
  - dir
  - PE Explorer
  - Disk Utilization Tool
  - md5sum
  - sha256sum
  - md5deep
+ Malware
  - Virus Total
  - IDA Pro
    + Immunity Debugger
    + Ghidra
  - Cuckoo (auto malware analysis)
+ Processes
  - tasklist
  - Process Monitor
  - Process Explorer
+ Services
  - Services.msc
  - MSConfig
  - net start
  - Task Scheduler
+ Volatile Memory
  - Rekall
+ Active Directory Tools

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

