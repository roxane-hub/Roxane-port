Threat Actors
----------------------------------------------------------------

Objectives:
---------------------------------------------------------------- 
+  Define, describe, and compare the different threat actors.

Outline:
----------------------------------------------------------------
+ Script Kiddies
+ Recreational Hackers
+ Professional Hackers
+ Cybercriminals
+ Hacktivists
+ State-Sponsored Hackers
+ Terrorists
+ Insider


Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

