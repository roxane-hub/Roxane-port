Host-Based Data Collection and Analysis
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Explain the purpose and characteristics of host-based data sources.

Outline:
----------------------------------------------------------------
+ Logs
  - System Logs
  - Service Logs
    + SSH
      - Time
      - Crypto Protocol
      - User
      - Success/Failure
    + HTTP
      - Methods (GET/POST)
      - Status Codes
      - Headers
      - User Agents
      - SSL Debugging
    + SQL Logs
      - Access Logs
      - Query Strings
    + SMTP
    + FTP
    + DNS
      - Suspicious lookups/domains
      - Types of DNS queries
    + Windows Event Logs
      - App log
      - System log
      - Security log
    + Linux Syslog
    + App Logs
      - Browser
      - HIPS Logs
      - AV Logs
      - Integrity Checker
+ Cloud
  - Audit Logs
  - Threat feeds
  - Security Bulletins
+ Vulnerability Testing Data
  - Third-party data
  - Automated/Software Testing Programs

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

