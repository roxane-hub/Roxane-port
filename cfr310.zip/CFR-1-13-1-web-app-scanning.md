Web App Scanning
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand the purpose of scanning web applications.
+  See some tools used to scan web apps.

Outline:
----------------------------------------------------------------
+  Web App Scanning
+  Tools

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

