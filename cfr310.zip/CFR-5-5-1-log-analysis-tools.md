Log Analysis Tools
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Explain the use of appropriate tools to analyze logs.

Outline:
----------------------------------------------------------------
+ Log Aggregator and Analytics Tools
  - SIEM
+ Linux Tools
  - grep
  - cut
  - diff
  - find
+ Windows Tools
  - find
  - WMIC
  - Event Viewer
+ Scripting Languages
  - Bash
  - PowerShell

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

