Threat Motives
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Define and describe the different threat motives.

Outline:
----------------------------------------------------------------
+ Financial Gain/Greed
+ Power
+ Fun/Thrills/Curiosity
+ Fame
+ Affiliation
+ Revenge
+ Human Error

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

