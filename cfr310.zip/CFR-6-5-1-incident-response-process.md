Incident Response Process
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand the phases in the Incident Response Process.

Outline:
----------------------------------------------------------------
+ Communication (occurs throughout all phases)
+ Preparation
+ Identification
  - Detection/Analysis
  - Collection
+ Containment
+ Eradication
+ Recovery
+ Post-Incident
  - Root Cause Analysis
  - Lessons Learned
  - Reporting and Documentation
    + Summary
    + Incident Description
    + Initial Investigation
    + Technical Description of the Attack
    + Impact of the Attack
    + Incident Response Plan
    + Incident Timeline Log
    + Action Plan/Remediation Plan
    + Attachments (logs)

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

