Asset Discovery
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Explore appropriate asset discovery methods and tools.

Outline:
----------------------------------------------------------------
+ Methods
  - Agent-based
  - Agentless
+ Tools
  - Nmap/Zenmap
  - Wireshark
  - TCPDump
  - Qualys
  - Snort
  - OpenVAS
  - Nessus
  - Burp Suite
  - Nikto

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

