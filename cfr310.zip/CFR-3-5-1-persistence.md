Persistence
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Explore methods attackers use to maintain access to compromised hosts.

Outline:
----------------------------------------------------------------
+ Rootkits
+ Backdoors
+ Hardware Backdoors
+ Rogue Accounts
+ Logic Bombs

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

