Attack Phases
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Define and describe the different attack phases.

Outline:
----------------------------------------------------------------
+ Reconnaissance   
+ Scanning 
+ Enumeration
+ Gaining Access
+ Persistence/Maintaining Access
+ Expanding Access
+ Covering Tracks

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

