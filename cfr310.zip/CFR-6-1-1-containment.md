Containment
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Explain appropriate containment methods and tools.

Outline:
----------------------------------------------------------------
+ Methods
  - White/Blacklist
  - IDS/IPS rules config
  - Network Segmentation
  - Web content filtering
  - Port blocking
+ Tools
  - Firewall
  - IDS/IPS
  - Web Proxy
  - Anti-Malware
  - Endpoint Security/Solutions
  - DLP

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

