Compliance and Standards
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand which regulatory compliances and standards you need to be familiar with as a first responder.

Outline:
----------------------------------------------------------------
+ Compliance
  - Things you MUST do
  - ISO 27001
  - PCI DSS
  - SOX
  - HIPAA
  - GLBA
  - GDPR
+ Standards
  - This is THE WAY to do something
  - ISO/IEC 27000 Series
  - ANSI/ISA-62443
  - NIST Special Publication 800 Series
  - Standard of Good Practice from ISF
  - NERC 1300 and RFC 2196

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

