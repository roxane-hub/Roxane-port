Password Attacks
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand the common password-based attacks used by hackers to gain access.

Outline:
----------------------------------------------------------------
+ Password Cracking
  - Brute Force
  - Guessing
  - Dictionary
  - Rainbow Tables
+ Password Sniffing

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+  https://ophcrack.sourceforge.io/tables.php
 

