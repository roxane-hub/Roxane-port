Frameworks and Best Practices
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Identify and be comfortable with cybersecurity frameworks and best practices.

Outline:
----------------------------------------------------------------
+ Frameworks
  - Cybersecurity Framework
  - CIS Critical Security Controls
  - COBIT
  - NIST Special Publication 800-61
  - RMF
+ Best Practices
  - OWASP
  - MITRE CAPEC


Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

