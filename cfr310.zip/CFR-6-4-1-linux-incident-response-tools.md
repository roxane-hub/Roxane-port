Linux-based Incident Response Tools
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Explore using Linux-based tools to analyze an incident.

Outline:
----------------------------------------------------------------
+ Network
  - Nmap
  - netstat
  - Wireshark
  - tcpdump
  - traceroute
  - arp
  - ifconfig
+ File System
  - lsof
  - dd
  - Disk Utilization Tool
  - md5sum
  - sha256sum
  - md5deep
  - strings
  - grep
+ Malware
  - Virus Total
  - IDA Pro
  - Cuckoo
+ Processes
  - top
  - htop
  - ps
+ Volatile Memory
  - free
  - Volatility
  - Rekall
+ Session Management
  - w/who
  - rwho
  - last/lastlog

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

