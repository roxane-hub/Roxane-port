Threat Targets
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Define and describe the different threat targets.

Outline:
----------------------------------------------------------------
+ Individuals
+ Non-Profits
+ Corporations
+ Governments
+ Critical Infrastructure
+ Systems
  - Mobile
  - IoT
  - SCADA (Supervisory Control And Data Acquisition)
    + PLC (Programmable Logic Controller)
    + ICS (Incident Command System)


Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+
 
