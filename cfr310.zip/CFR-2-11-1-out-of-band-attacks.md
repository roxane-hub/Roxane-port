Out-Of-Band Attacks
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand how to infiltrate a target through indirect paths or exploiting a trust relationship.

Outline:
----------------------------------------------------------------
+ OEM Supply-Chain Attacks
+ Watering Hole

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

