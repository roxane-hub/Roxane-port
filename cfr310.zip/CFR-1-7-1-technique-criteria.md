Technique Criteria
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand the types of attack techniques that hackers use during an attack.

Outline:
----------------------------------------------------------------
+ Targeted/Non-Targeted
+ Direct/Indirect
+ Stealth/Non-Stealth
+ Client-Side/Server-Side

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

