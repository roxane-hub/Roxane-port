Covering Your Tracks
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Explore methods attackers use to avoid detection by security personnel.

Outline:
----------------------------------------------------------------
+ Clearing logs
+ Modifying logs
+ Erasing files
+ Anti-Forensics techniques

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

