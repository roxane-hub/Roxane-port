Indicators of Compromise
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand how to recognize possible indicators of compromise.

Outline:
----------------------------------------------------------------
+ Unauthorized programs in startup
+ Malicious Software
  - Presence of Attack Tools
+ Registry Entries
+ Unusual network traffic
  - Bandwidth Usage
  - Malicious Network Communication
+ Off-hours usage
+ New Admin/User Accounts
+ Guest account usage
+ Unknown open ports
+ Unknown use of protocols
+ Service disruption
+ Website defacement
+ Unauthorized changes/modifications
  - Suspicious files
  - Patches
+ Recipient of suspicious emails
+ Unauthorized sessions
+ Failed Logins
+ Rogue hardware

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

