Impact of Attacks
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand how a data breach or DoS attack could impact an organization.

Outline:
----------------------------------------------------------------
+ Financial Loss
  - Direct
  - Indirect
+ Data Exfiltration
+ Customer Relationship
+ Business Reputation
+ Capacity
+ Time
+ Compliance/Notification
+ Litigation
+ Insurance Costs
+ Customer Protection
+ Cybersecurity Improvements Required
+ Legal Fees
+ Public Relationship Management

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

