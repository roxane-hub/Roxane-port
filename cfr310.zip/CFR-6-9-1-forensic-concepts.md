Forensic Concepts
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Explain the importance of concepts unique to forensic analysis.

Outline:
----------------------------------------------------------------
+ Evidence collection, preservation, and security (just "Evidence" for slide)
  - Digital
    + Imaging
    + Hashing
  - Physical
    + Evidence bags and tags
+ Chain of Custody
+ Forensic Investigation
  - Static analysis
  - Dynamic analysis
+ Forensic collection and analysis tools
  - FTK
  - EnCase
  - eDiscovery
  - Forensic Explorer
  - Kali Forensic Mode
  - CAINE
  - SANS SIFT

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

