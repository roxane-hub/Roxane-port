Keylogging
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Explore hardware and software methods for capturing keystrokes.

Outline:
----------------------------------------------------------------
+ Software Based
+ Hardware Based

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ https://www.keelog.com

