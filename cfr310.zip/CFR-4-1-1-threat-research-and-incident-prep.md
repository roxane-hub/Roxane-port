Threat Research and Incident Prep
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand how security professionals keep abreast of the current threat landscape.
+  Understand how to use data to prepare for security incidents.

Outline:
----------------------------------------------------------------
+ Latest technologies, vulnerabilities, threats, and exploits
+ Utilize trend data to determine likelihood and threat attribution
+ New Tools/Prevention Techniques
+ Data Gathering/Research Tools/Cybersecurity Intelligence
  - Journals
  - Vulnerability Databases
  - Books
  - Blogs
  - Intelligence Feeds
  - Security Advisories
  - Social Network Sites
  - Automated Threat Scoring
+ Commonly Targeted Assets
  - Financial Info
  - Account Info
  - IP
  - Trade Secrets
  - PII/PHI
  - National Security Data and Identities
  - Computing Resources
  - Power Resources

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

