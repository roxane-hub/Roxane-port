Network Data Collection and Analysis
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand the purpose and characteristics of network-based data sources.

Outline:
----------------------------------------------------------------
+ Device config files
+ Firewall Logs
+ WAF Logs
+ IDS/IPS Logs
+ Router/Switch Logs
+ Carrier Provider Logs
+ Proxy Logs
+ Wireless
  - WAP Logs
  - WIPS Logs
  - Controller Logs
+ Network Sniffer
  - Packet Captures
  - Traffic Log
  - Flow Data
+ Device State Data
  - CAM Tables
  - Routing Tables
  - NAT Tables
  - DNS Cache
  - ARP Cache
+ SDN

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

