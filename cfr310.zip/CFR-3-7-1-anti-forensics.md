Anti-Forensics
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand methods attackers use to thwart investigative forensic techniques.

Outline:
----------------------------------------------------------------
+ Buffer Overflows
+ Virtual Machine Detection
+ Sandbox Detection
+ Shredding

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

