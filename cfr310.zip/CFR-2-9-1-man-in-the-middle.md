Man-In-The-Middle
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand how attackers perform man-in-the-middle attacks to access hosts and data.

Outline:
----------------------------------------------------------------
+ ARP Cache Poisoning/ARP Spoofing
+ ICMP Redirect
+ DHCP Spoofing
+ NBNS Spoofing
+ Session Hijacking
+ DNS Poisoning
+ WPAD

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

