Lateral Movement
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Exploring methods used by attackers to jump from a compromised host into other connected network hosts.

Outline:
----------------------------------------------------------------
+ Pass-the-Hash (PTH)
+ Golden Ticket
+ PsExec
+ WMIC
+ Remote Access Services

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

