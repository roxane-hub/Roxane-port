Penetration Testing
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand the purpose and scope of a penetration test.

Outline:
----------------------------------------------------------------
+  What is a pentest?
+  How does it differ from a vulnerability assessment?

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

