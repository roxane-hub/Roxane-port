Footprinting
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand the definition and purpose of Footprinting.
+  Gain a practical understanding of how Footprinting is done.

Outline:
----------------------------------------------------------------
+ Open Source Intelligence (OSINT)
+ Closed Source Intelligence

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

