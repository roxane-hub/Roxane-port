Pivoting
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand methods for pivoting from one compromised system into other areas of the connected network.

Outline:
----------------------------------------------------------------
+ VPN
+ SSH Tunnels
+ Routing Tables

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

