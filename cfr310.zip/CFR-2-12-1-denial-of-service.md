Denial-of-Service
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand how denial-of-service attacks are used by hackers for various reasons.

Outline:
----------------------------------------------------------------
+ DDoS
  - LOIC/HOIC
+ Resource Exhaustion
+ Forced System Outage
+ Packet Generators

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+


