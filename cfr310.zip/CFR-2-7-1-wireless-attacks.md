Wireless Attacks
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand common wireless attacks used to breach security by threat actors.

Outline:
----------------------------------------------------------------
+ Wireless Cracking
+ Wireless Client Attack
+ Infrastructure Attacks

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

