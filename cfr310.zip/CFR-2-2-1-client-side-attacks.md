Client-Side Attacks
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand how client-side applications and browsers can be exploited by hackers to gain access

Outline:
----------------------------------------------------------------
+  Application exploits
+  Browser exploits
   - XSS Types

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

