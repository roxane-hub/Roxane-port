Social Engineering
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand how social engineering is used to bypass security.
+  Learn about both physical and digital forms of social engineering.

Outline:
----------------------------------------------------------------
+ Phishing
+ Spear Phishing
+ Quid Pro Quo
+ Baiting
+ Shoulder Surfing
+ Tailgating

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

