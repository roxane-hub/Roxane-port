Incident Response Preparation
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Explain the importance of best-practices in preparation for Incident Response.

Outline:
----------------------------------------------------------------
+ Preparation and Planning
  - Up-to-date contact list
  - Up-to-date IR toolkit
+ Ongoing Training
  - Incident Responder
  - Incident Response Team
  - Management
  - Tabletop exercise
+ Internal Communication Methods
  - Secure Channels
  - Out-of-band Communication
+ External Communication Plan
  - Local Law Enforcement
  - Stockholders
  - Breach Victims
  - Media
  - Other CERTs/CSIRTs
  - Vendors
+ Organizational Documentation
  - Policies
  - Procedures
  - IR Plan
  - Security Configuration Controls
  - Baseline Configurations
  - Hardening Documentation
+ Escalation Procedures
  - Chain of Command

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

