Mobile Threats
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Understand common attacks against mobile platforms.
+  Understand trends in mobile security.

Outline:
----------------------------------------------------------------
+ Malicious Apps
+ Malicious Texts
+ Hijacking/Rooting

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

