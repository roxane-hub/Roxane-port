Common Vulnerable Areas
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Identify common areas of vulnerability in a given network.

Outline:
----------------------------------------------------------------
+ Users
+ Operating systems
+ Applications
  - Networking Software
    + Network operations and management
    + Firewall
    + Network security applications
  - Database software
+ Network Devices
  - Access points
  - routers
  - Wireless routers
  - Switches
  - Firewall
+ Network Infrastructure
  - Network Configurations
  - Network Services
    + DSL
    + Wireless Protocols
    + IP Addressing
+ IoT
+ Configuration Files

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

