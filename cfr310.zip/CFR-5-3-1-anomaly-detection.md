Anomaly Detection
----------------------------------------------------------------

Objectives:
----------------------------------------------------------------
+  Explore how to use real-time data analysis to detect anomalous activity.

Outline:
----------------------------------------------------------------
+ Log Collection
  - Agent-Based
  - Agentless
  - Syslog
+ Log Auditing
  - Source Validation
  - Verification of Log Integrity
  - Evidence Collection
+ Log Enrichment
  - IP Address and Host Name Resolution
  - Field Name Consistency
  - Time Zones
+ Alerts, Reports, and Event Correlation
  - Threat Hunting
  - Long Tail Analysis
  - Intrusion Detection
  - Behavioral Monitoring
+ Log Retention
  - Industry Compliance/Regulatory Requirements
+ Anomalies
  - False Positives
  - Superhuman logins/geo-velocity
  - APT Activity
  - Botnets

Code Snippets:
----------------------------------------------------------------
+ 

Resources:
----------------------------------------------------------------
+ 

